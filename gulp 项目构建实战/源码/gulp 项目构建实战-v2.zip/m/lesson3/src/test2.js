var should = require('should');

describe('test two', function () {
   it('test 2', function () {
    var obj = {name:'jikexueyuan'};
    var obj2;
    should.exist(obj);
   })
});