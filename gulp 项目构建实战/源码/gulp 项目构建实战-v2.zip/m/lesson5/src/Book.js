module.exports = function Book(name, price) {
    this.name = name;
    this.price = price;
};