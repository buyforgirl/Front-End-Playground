var Book = require('./Book');

var b1 = new Book('node.js',60);
var b2 = new Book('javascript 2016',80);

console.log(b1,b2);