'use strict';

const react = require('react');

class MYUI extends react.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div>hello gulp react , and es6 to es5.</div>
        )
    }
}