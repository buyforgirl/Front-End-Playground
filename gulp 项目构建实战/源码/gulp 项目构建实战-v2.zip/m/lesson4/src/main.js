var User = require('./User');
console.log(new User('ji ke xue yuan'));