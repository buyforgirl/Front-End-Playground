module.exports = function User(name){
    this.name = name;
};